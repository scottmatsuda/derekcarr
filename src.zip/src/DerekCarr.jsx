import React, { Component } from "react";
import { Card, Grid, Button, Box } from '@mui/material';
import { getAllPlayers, getPlayerById }from "./services";
// import YesChart from "./YesChart";
// import NoChart from "./NoChart";
import { BrowserRouter as Router, Switch, Link } from "react-router-dom";
import PropTypes from 'prop-types';

class DerekCarr extends Component {
  constructor(props) {
    super(props);
    // console.log('props inside of DerekCarr contructor', props)
    this.state = {
      playerId: 0,
      fullName: '',
      playerImage: '',
      teamImage: '',
      isYesClicked: false,
      isNoClicked: false
    };
  }

  componentDidMount() {
    // let tempToken = '98339262-652f-4113-a5ac-ec7848402ce0';
    getAllPlayers()
      .then(this.onGetAllPlayersSuccess)
      .catch(this.onGetAllPlayersError);
  }

  onGetAllPlayersSuccess = (response) => {
    // console.log('response from onGetAllPlayersSuccess', response)
    let { playerId, fullName, playerImage, teamImage } = response[1];
    this.setState(() => {
      return {
        playerId, fullName, playerImage, teamImage
      };
    });
    
    // getPlayerById(playerId)
    //   .then(this.ongetPlayerByIdSuccess)
    //   .catch(this.ongetPlayerByIdError)
  };

  onGetAllPlayersError = (error) => {
    console.error(error);
  };

  onYesClick = () => {
    console.log('this.props', this.props)
    this.props.history.push("/yes");
  };

  // ongetPlayerByIdSuccess = (response) => {
  //   console.log('response from ongetPlayerByIdSuccess I', response);
  //   this.setState({
  //     isYesClicked: true
  //   })
  //   // this.props.history.push("/yes");
  //   if (this.state.isYesClicked) {
  //     // console.log('response from ongetPlayerByIdSuccess II', response);

  //     return (
  //       <YesChart

  //         derekCarrArray={response}
  //         // logger={console.log('derekCarrArray', derekCarrArray)}
  //         key={`DerekCarrWeek-${response.week}`}
  //       />
  //     )
  //   } else {
  //     return (
  //       <NoChart
  //         derekCarrArray={response}
  //         key={`DerekCarrWeek-${response.week}`}
  //       />
  //     )
  //   }
    
  // };

  // ongetPlayerByIdError = (error) => {
  //   console.error(error);
  // }

  onNoClick = () => {
    console.log('this from onNoClick', this)
    // console.log('this.props', this.props)
    this.props.history.push("/no");
  };
  
  render() {

    // let {isYesClicked} = this.state;
    // console.log('isYesClicked', isYesClicked)
    // const renderChart = () => {
    //   if (isYesClicked) {
    //     console.log('this', this)
    //     // this.props.history.push('/yes')
    //     return < YesChart />;
    //   } else {
    //     return < NoChart />;
    //   }
    // }

    return (
        <React.Fragment>
            <h1 align="center">Is {this.state.fullName || "Las Vegas Raiders quarterback Derek Carr"} worth $121.5 Million over 3 years?</h1>
            <Grid columnSpacing={3} align="center" item xs={2} padding={10} >
                <Card className="mb-4" style={{ width: '36vh', height: '40vh' }} >
                    <div className="card-img-wrapper">
                        <img alt="..." className="card-img-top mt-3" src={this.state.playerImage} style={{ height: '40vh' }} />
                    </div>
                </Card>
            </Grid >
            <Box display="flex" justifyContent="space-between" padding={8}>
                <Grid item xs={6}>
                  <Link to="/yes">
                    <Button 
                      onClick={this.onYesClick} color="success" variant="contained">Yes, he's worth every penny
                      <img alt="..." className="card-img-top mt-3" src={this.state.teamImage} style={{ height: '10vh' }} />
                    </Button>
                  </Link>
                </Grid>
                <Grid item xs={6}>
                  <Link to="/no">
                    <Button onClick={this.onNoClick} color="error" variant="contained">No, he's trash
                        <img alt="..." className="card-img-top mt-3" src={this.state.teamImage} style={{ height: '10vh' }} />
                    </Button>
                  </Link>
                    
                </Grid>
            </Box>
           
          {/* {renderChart()} */}
      </React.Fragment>
    );
  }
}

DerekCarr.propTypes = {
  history: PropTypes.shape({
  push: PropTypes.func,
  })
};


export default DerekCarr;
