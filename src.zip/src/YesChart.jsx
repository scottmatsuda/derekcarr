import React, { Component } from "react";
import { Card, Grid, Button, Box } from '@mui/material';
import { getPlayerById }from "./services";
import PropTypes from 'prop-types';
import { Line } from "react-chartjs-2";
import { render } from "@testing-library/react";


class YesChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
        int: [], 
        TDtoIntRatio: 0, 
        week: [], 
        totalTDs: 0, 
        totalTDsArray: [],
        totalSacks: 0
        }
       
  }
      

  componentDidMount() {
    // let tempToken = '98339262-652f-4113-a5ac-ec7848402ce0';
    let playerId = 2543499;
    getPlayerById(playerId)
      .then(this.onGetAllSuccess)
      .catch(this.onGetAllError);
  }

  onGetAllSuccess = (response) => {
    
    let sack = response.map((sack) => sack.Sack)
    let week = response.map((week) => week.week)
    let int = response.map((int) => int.Int)
    let rshTD = response.map((rush) => rush.RshTD)
    let psTD = response.map((pass) => pass.PsTD)
    let totalTDsArray = psTD.map( (val, i) => val + rshTD[i] );
    
    let totalSacks = sack.reduce((a, b) => {
        return a + b;
    })
    let totalTDs = totalTDsArray.reduce((a, b) => {
        return a + b;
    })
    let totalInts = int.reduce((a, b) => {
        return a + b;
    })
    
    let TDtoIntRatio = totalTDs / totalInts;
    
    this.setState(() => {
        return {
            int: int,
            week: week,
            TDtoIntRatio: TDtoIntRatio,
            totalTDs: totalTDs,
            totalTDsArray: totalTDsArray,
            totalSacks: totalSacks
        };
    });
  }

  onGetAllError = (error) => {
    console.error(error);
  };


//     const config = {
//         type: 'line',
//         data: data,
//       };

//     //   const labels = Utils.months({count: 7});


//     var data = {
//         labels: ["Week 1", "Week 2", "Week 3", "Week 4", "Week 5", "Week 6", "Week 7"],
//         datasets: [
//           {
//             label: "Passing Touchdowns",
//             // data: [psTD[0], psTD[1], psTD[2], psTD[3], psTD[4], psTD[5], psTD[6], psTD[7], psTD[8], psTD[9], psTD[10]],
//             data: psTD,
//             fill: true,
//             backgroundColor: "rgba(75,192,192,0.2)",
//             borderColor: "rgba(75,192,192,1)"
//           },
//           {
//             label: "Interceptions",
//             data: int,
//             // data: [int[0], int[0], int[0], int[0], 54, 76],
//             fill: false,
//             borderColor: "#742774"
//           }
//         ]
//       };
    
//   };

  

//   onYesClick = () => {
//     console.log('this', this);
//     const { match, location, history } = this.props;
//     console.log('this.props.history', this.props.history);
//     // console.log('props', props)
//     // console.log('this.props', this.props)
//     // this.props.history.push("/yes");

// };

//   onNoClick = () => {
//     console.log('this', this)
//     // console.log('this.props', this.props)
//     this.props.history.push("/no");
// };
  

  render() {
      
    return (

        // <div className="YesChart">
        //     <Line data={this.data} />
        // </div>
        <React.Fragment>
           <h2>Despite a 4-12 record and being sacked {this.state.totalSacks} times, Derek Carr compiled a total TD:Int ratio of {this.state.TDtoIntRatio}.0</h2>
           {/* <Line data={this.props.data} /> */}
      </React.Fragment>
    );
  }
}  

  YesChart.propTypes = {
    match: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    history: PropTypes.object.isRequired
  };

export default YesChart;


// const derekCarrData = props.derekCarrArray

