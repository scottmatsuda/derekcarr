import React, { Component, Fragment } from 'react';
import DerekCarr from './DerekCarr';
import YesChart from './YesChart';
import NoChart from './NoChart';
// import { Router, withRouter } from 'react-router-dom';
import { BrowserRouter } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import { Route } from 'react-router-dom';
import { BrowserRouter as Router, Switch, Link } from "react-router-dom";


class App extends Component {
  render() {
    return (
       <Router>
          {/* <BrowserRouter> */}
          {/* <YesChart /> */}
          {/* <Yes /> */}
          {/* </BrowserRouter> */}
          {/* <Router> */}
          <Route path="/" exact={true} component={DerekCarr} />
          <Route path="/yes" exact={true} component={YesChart} />
          <Route path="/no" exact={true} component={NoChart} />
        </Router>

    );
  }
  
}
// export default App;
// export default withRouter(App);
// export default BrowserRouter(App);
export default withRouter(App);