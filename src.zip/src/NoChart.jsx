// import { Line } from 'react-chartjs';
import React, { Component, Fragment } from "react";
import PropTypes from 'prop-types';
import { getPlayerById }from "./services";

// import { Line } from "react-chartjs-2";

class NoChart extends Component {
    
    constructor(props) {
        super(props);
        this.state = {
            derekCarrData: [{
                playerId: 0,
                fullName: "",
                playerImage: "",
                seasonYear: 2018,
                week: 0,
                gameDate: [],
                team: "",
                teamImage: "",
                opponent: "",
                opponentImage: "",
                Att: 0,
                Cmp: 0,
                Sack: 0,
                Int: [],
                PsYds: 0,
                PsTD: [],
                Rush: 0,
                RshYds: 0,
                RshTD: []
            }]
            }
           
      }
      componentDidMount() {
        // let tempToken = '98339262-652f-4113-a5ac-ec7848402ce0';
        let playerId = 2543499;
        getPlayerById(playerId)
          .then(this.onGetAllSuccess)
          .catch(this.onGetAllError);
      }
    
      onGetAllSuccess = (response) => {
        console.log('response from onGetAllSuccess in YesChart.jsx', response)
        console.log('response.length', response.length)
        
        let psTD = [];
        let int = [];
        let gameDate = [];
        let week = []
        for (let i = 0; i < response.length; i++) {
            psTD.push(response[i].PsTD)
            int.push(response[i].Int)
            gameDate.push(response[i].gameDate)
            week.push(response[i].week)
        }
      }
    
    // console.log('props', props);
    // const derekCarrData = props.derekCarrArray

    // const data = {
    //     labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    //     datasets: [
    //       {
    //         label: "First dataset",
    //         data: [33, 53, 85, 41, 44, 65],
    //         fill: true,
    //         backgroundColor: "rgba(75,192,192,0.2)",
    //         borderColor: "rgba(75,192,192,1)"
    //       },
    //       {
    //         label: "Second dataset",
    //         data: [33, 25, 35, 51, 54, 76],
    //         fill: false,
    //         borderColor: "#742774"
    //       }
    //     ]
    //   };
    render() {
        return (
    
            // <div className="YesChart">
            //     <Line data={this.data} />
            // </div>
            <React.Fragment>
               <h1>No, Fucker!</h1>
               {/* <Line data={this.props.data} /> */}
          </React.Fragment>
        );
      }
    }  

NoChart.propTypes = {
    match: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    history: PropTypes.object.isRequired
  };

export default NoChart;